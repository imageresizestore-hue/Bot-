"""Deterministic SMC analysis primitives for the paper-first trading pipeline.

The engine deliberately separates market reading from execution. It never places
an order by itself; callers must pass a validated setup to a broker adapter.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, time
from enum import Enum
from typing import Iterable, Sequence
from zoneinfo import ZoneInfo


IST = ZoneInfo("Asia/Kolkata")


class Bias(str, Enum):
    LONG = "long"
    SHORT = "short"
    NEUTRAL = "neutral"


class Trend(str, Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    RANGING = "ranging"
    UNCLEAR = "unclear"


@dataclass(frozen=True)
class Candle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass(frozen=True)
class AsianRange:
    low: float
    high: float
    candle_count: int


@dataclass(frozen=True)
class SessionRange:
    name: str
    low: float
    high: float
    candle_count: int
    date: str


@dataclass(frozen=True)
class Structure:
    trend: Trend
    bias: Bias
    bos: bool
    choch: bool
    reason: str


@dataclass(frozen=True)
class FVG:
    direction: Bias
    low: float
    high: float
    midpoint: float
    formed_at: datetime | None = None


@dataclass(frozen=True)
class Setup:
    valid: bool
    bias: Bias
    entry: float | None
    stop_loss: float | None
    target: float | None
    risk_reward: float | None
    session: str
    reasons: tuple[str, ...]
    invalidation: tuple[str, ...]

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class TradeAudit:
    grade: str
    verdict: str
    reasons: tuple[str, ...]
    checklist: tuple[tuple[str, bool], ...]

    def as_dict(self) -> dict:
        return {
            "grade": self.grade,
            "verdict": self.verdict,
            "reasons": list(self.reasons),
            "checklist": [
                {"label": label, "passed": passed}
                for label, passed in self.checklist
            ],
        }


TIMEFRAME_ORDER = ("1d", "1h", "30m", "15m", "5m", "1m")


@dataclass(frozen=True)
class TimeframeRead:
    timeframe: str
    trend: Trend
    bias: Bias
    bos: bool
    choch: bool
    swing_high: float | None
    swing_low: float | None
    fvg_low: float | None
    fvg_high: float | None
    last_close: float | None
    status: str
    reason: str

    def as_dict(self) -> dict:
        return {
            "timeframe": self.timeframe,
            "trend": self.trend.value,
            "bias": self.bias.value,
            "bos": self.bos,
            "choch": self.choch,
            "swingHigh": self.swing_high,
            "swingLow": self.swing_low,
            "fvgLow": self.fvg_low,
            "fvgHigh": self.fvg_high,
            "lastClose": self.last_close,
            "status": self.status,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class MultiTimeframeAnalysis:
    trend: Trend
    bias: Bias
    confidence: int
    reads: tuple[TimeframeRead, ...]
    reasons: tuple[str, ...]
    invalidation: tuple[str, ...]

    def as_dict(self) -> dict:
        return {
            "trend": self.trend.value,
            "bias": self.bias.value,
            "confidence": self.confidence,
            "timeframes": [read.as_dict() for read in self.reads],
            "reasons": list(self.reasons),
            "invalidation": list(self.invalidation),
        }


def current_session(now: datetime | None = None) -> str:
    """Return the IST session used by the bot's hard session gate."""

    local = (now or datetime.now(IST)).astimezone(IST)
    clock = local.time()
    if time(6, 0) <= clock < time(12, 30):
        return "asian"
    if time(12, 30) <= clock < time(17, 30):
        return "london"
    if time(17, 30) <= clock < time(23, 0):
        return "new_york"
    return "outside"


def asian_range(candles: Sequence[Candle]) -> AsianRange | None:
    """Build the Asian range from candles between 06:00 and 12:30 IST."""

    asian = [
        candle
        for candle in candles
        if time(6, 0) <= candle.timestamp.astimezone(IST).time() < time(12, 30)
    ]
    if not asian:
        return None
    return AsianRange(
        low=min(candle.low for candle in asian),
        high=max(candle.high for candle in asian),
        candle_count=len(asian),
    )


SESSION_WINDOWS = {
    "asian": (time(6, 0), time(12, 30)),
    "london": (time(12, 30), time(17, 30)),
    "new_york": (time(17, 30), time(23, 0)),
}
PREVIOUS_SESSION = {"asian": "new_york", "london": "asian", "new_york": "london"}


def previous_session_range(
    candles: Sequence[Candle],
    active_session: str,
    now: datetime | None = None,
) -> SessionRange | None:
    """Map the active session to its most recent completed session range."""

    target_session = PREVIOUS_SESSION.get(active_session)
    if target_session is None or not candles:
        return None
    local_now = (now or datetime.now(IST)).astimezone(IST)
    target_date = local_now.date()
    if active_session == "asian":
        from datetime import timedelta

        target_date -= timedelta(days=1)
    start, end = SESSION_WINDOWS[target_session]
    selected = [
        candle
        for candle in candles
        if candle.timestamp.astimezone(IST).date() == target_date
        and start <= candle.timestamp.astimezone(IST).time() < end
    ]
    if not selected:
        return None
    return SessionRange(
        name=target_session,
        low=min(candle.low for candle in selected),
        high=max(candle.high for candle in selected),
        candle_count=len(selected),
        date=target_date.isoformat(),
    )


def _recent_swings(candles: Sequence[Candle]) -> tuple[list[float], list[float]]:
    highs: list[float] = []
    lows: list[float] = []
    for index in range(1, len(candles) - 1):
        before, candle, after = candles[index - 1 : index + 2]
        if candle.high > before.high and candle.high > after.high:
            highs.append(candle.high)
        if candle.low < before.low and candle.low < after.low:
            lows.append(candle.low)
    return highs, lows


def read_structure(candles: Sequence[Candle]) -> Structure:
    """Read directional structure from confirmed three-candle swing points."""

    if len(candles) < 7:
        return Structure(Trend.UNCLEAR, Bias.NEUTRAL, False, False, "Not enough candles")

    highs, lows = _recent_swings(candles)
    if len(highs) < 2 or len(lows) < 2:
        return Structure(Trend.UNCLEAR, Bias.NEUTRAL, False, False, "No confirmed swing structure")

    bullish = highs[-1] > highs[-2] and lows[-1] > lows[-2]
    bearish = highs[-1] < highs[-2] and lows[-1] < lows[-2]
    if bullish:
        return Structure(Trend.BULLISH, Bias.LONG, True, False, "Higher highs and higher lows")
    if bearish:
        return Structure(Trend.BEARISH, Bias.SHORT, True, False, "Lower highs and lower lows")
    return Structure(Trend.RANGING, Bias.NEUTRAL, False, True, "Swing sequence is mixed; wait for displacement")


def analyze_timeframe(timeframe: str, candles: Sequence[Candle]) -> TimeframeRead:
    """Read confirmed structure and nearby liquidity/FVG levels for one timeframe."""

    structure = read_structure(candles)
    highs, lows = _recent_swings(candles)
    fvg = select_reacting_fvg(candles, structure.bias) if structure.bias != Bias.NEUTRAL else None
    if structure.trend in {Trend.BULLISH, Trend.BEARISH}:
        status = "confirmed"
    elif structure.trend == Trend.RANGING:
        status = "sideways"
    else:
        status = "unclear"
    return TimeframeRead(
        timeframe=timeframe,
        trend=structure.trend,
        bias=structure.bias,
        bos=structure.bos,
        choch=structure.choch,
        swing_high=highs[-1] if highs else None,
        swing_low=lows[-1] if lows else None,
        fvg_low=fvg.low if fvg else None,
        fvg_high=fvg.high if fvg else None,
        last_close=candles[-1].close if candles else None,
        status=status,
        reason=structure.reason,
    )


def analyze_multi_timeframe(
    candles_by_timeframe: dict[str, Sequence[Candle]],
) -> MultiTimeframeAnalysis:
    """Require directional agreement from 1D through 1M before allowing a bias.

    A lower-timeframe break is deliberately ignored when a higher timeframe is
    ranging, unclear, or pointing the other way. This makes the paper worker
    less eager around fake breakouts and isolated liquidity grabs.
    """

    reads = tuple(
        analyze_timeframe(timeframe, candles_by_timeframe.get(timeframe, ()))
        for timeframe in TIMEFRAME_ORDER
    )
    directional = [
        read
        for read in reads
        if read.bias != Bias.NEUTRAL and read.trend in {Trend.BULLISH, Trend.BEARISH}
    ]
    aligned_bias = directional[0].bias if directional else Bias.NEUTRAL
    fully_aligned = (
        len(directional) == len(reads)
        and all(read.bias == aligned_bias for read in reads)
    )
    daily = reads[0]
    if fully_aligned:
        trend = Trend.BULLISH if aligned_bias == Bias.LONG else Trend.BEARISH
        confidence = 92
        reasons = [
            f"{read.timeframe} confirms {read.trend.value} structure"
            for read in reads
        ]
        reasons.append("All six timeframes agree; lower-timeframe break is not isolated")
    else:
        trend = daily.trend if daily.trend != Trend.UNCLEAR else Trend.RANGING
        aligned_count = sum(read.bias == aligned_bias for read in reads) if aligned_bias != Bias.NEUTRAL else 0
        confidence = min(68, 25 + aligned_count * 8)
        reasons = [
            f"{read.timeframe}: {read.status} — {read.reason}"
            for read in reads
        ]
    invalidation = (
        "Reject if 1D or 1H structure changes against the bias",
        "Reject if 30m/15m closes fail to confirm the displacement",
        "Reject isolated 5m/1m breaks without higher-timeframe alignment",
        "Reject entries while any required timeframe is sideways or unclear",
    )
    return MultiTimeframeAnalysis(
        trend=trend,
        bias=aligned_bias if fully_aligned else Bias.NEUTRAL,
        confidence=confidence,
        reads=reads,
        reasons=tuple(reasons),
        invalidation=invalidation,
    )


def validate_multi_timeframe_setup(
    candles_by_timeframe: dict[str, Sequence[Candle]],
    now: datetime | None = None,
) -> tuple[Setup, MultiTimeframeAnalysis]:
    """Validate a setup only after all six timeframes agree."""

    analysis = analyze_multi_timeframe(candles_by_timeframe)
    session = current_session(now)
    if session not in {"asian", "london", "new_york"}:
        return (
            Setup(
                False,
                Bias.NEUTRAL,
                None,
                None,
                None,
                None,
                session,
                ("Outside the configured Asian/London/New York sessions",),
                ("Session filter failed",),
            ),
            analysis,
        )
    if analysis.bias == Bias.NEUTRAL:
        return (
            Setup(
                False,
                Bias.NEUTRAL,
                None,
                None,
                None,
                None,
                session,
                analysis.reasons,
                analysis.invalidation,
            ),
            analysis,
        )

    range_candles = candles_by_timeframe.get("15m", ())
    entry_candles = candles_by_timeframe.get("5m", ())
    range_ = previous_session_range(range_candles, session, now)
    if range_ is None:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("Previous session range is not available",), ("Wait for the completed session range",)),
            analysis,
        )
    sell_side, buy_side = liquidity_sweep(entry_candles, range_)
    expected_sweep = sell_side if analysis.bias == Bias.LONG else buy_side
    if not expected_sweep:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("Required 5m liquidity sweep is not confirmed",), ("No sweep; do not anticipate the entry",)),
            analysis,
        )
    fvg = select_reacting_fvg(entry_candles, analysis.bias)
    if fvg is None:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("No unmitigated 5m FVG was tapped and rejected",), ("Wait for the correct FVG tap and reaction",)),
            analysis,
        )
    order_block = find_order_block(candles_by_timeframe.get("15m", ()), analysis.bias)
    if order_block is None:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("No confirmed 15m order block before displacement",), ("Wait for an order-block reaction",)),
            analysis,
        )
    equilibrium = (range_.low + range_.high) / 2
    in_correct_location = (
        fvg.midpoint <= equilibrium
        if analysis.bias == Bias.LONG
        else fvg.midpoint >= equilibrium
    )
    if not in_correct_location:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("FVG tap is in the wrong premium/discount half of the reference range",), ("Longs require discount; shorts require premium",)),
            analysis,
        )
    risk = abs(fvg.midpoint - (range_.low if analysis.bias == Bias.LONG else range_.high))
    if risk <= 0:
        return (
            Setup(False, analysis.bias, None, None, None, None, session, ("Invalid risk distance",), ("Do not trade a zero-risk setup",)),
            analysis,
        )
    target = fvg.midpoint + 2 * risk if analysis.bias == Bias.LONG else fvg.midpoint - 2 * risk
    return (
        Setup(
            True,
            analysis.bias,
            fvg.midpoint,
            range_.low if analysis.bias == Bias.LONG else range_.high,
            target,
            2.0,
            session,
            tuple([
                "All six timeframes aligned",
                f"{range_.name.replace('_', ' ').title()} reference range swept",
                "5m displacement FVG was tapped and rejected",
                "15m order block confirmed",
                "FVG is in the correct premium/discount half",
                *analysis.reasons,
            ]),
            analysis.invalidation,
        ),
        analysis,
    )


def liquidity_sweep(candles: Sequence[Candle], range_: AsianRange | SessionRange) -> tuple[bool, bool]:
    """Return (sell-side sweep, buy-side sweep) from the latest confirmed candle."""

    if not candles:
        return False, False
    latest = candles[-1]
    return latest.low < range_.low and latest.close > range_.low, latest.high > range_.high and latest.close < range_.high


def find_fvg(candles: Sequence[Candle], direction: Bias) -> FVG | None:
    """Find the latest three-candle fair value gap in the requested direction."""

    for first, _, third in reversed(list(zip(candles, candles[1:], candles[2:]))):
        if direction == Bias.LONG and third.low > first.high:
            return FVG(direction, first.high, third.low, (first.high + third.low) / 2, third.timestamp)
        if direction == Bias.SHORT and third.high < first.low:
            return FVG(direction, third.high, first.low, (third.high + first.low) / 2, third.timestamp)
    return None


def select_reacting_fvg(candles: Sequence[Candle], direction: Bias) -> FVG | None:
    """Return an unmitigated FVG that the latest candle tapped and rejected."""

    if direction == Bias.NEUTRAL or len(candles) < 5:
        return None
    latest = candles[-1]
    candidates: list[FVG] = []
    for first, _, third in zip(candles, candles[1:], candles[2:]):
        if direction == Bias.LONG and third.low > first.high:
            candidates.append(FVG(direction, first.high, third.low, (first.high + third.low) / 2, third.timestamp))
        elif direction == Bias.SHORT and third.high < first.low:
            candidates.append(FVG(direction, third.high, first.low, (third.high + first.low) / 2, third.timestamp))
    for candidate in reversed(candidates):
        formed_index = next(
            (index for index, candle in enumerate(candles) if candle.timestamp == candidate.formed_at),
            len(candles) - 3,
        )
        after = candles[formed_index + 1 :]
        if direction == Bias.LONG and any(candle.close < candidate.low for candle in after):
            continue
        if direction == Bias.SHORT and any(candle.close > candidate.high for candle in after):
            continue
        touched = latest.low <= candidate.high and latest.high >= candidate.low
        rejected = latest.close > candidate.midpoint if direction == Bias.LONG else latest.close < candidate.midpoint
        if touched and rejected:
            return candidate
    return None


def find_order_block(
    candles: Sequence[Candle],
    direction: Bias,
) -> tuple[float, float] | None:
    """Find the latest opposite candle before directional displacement."""

    for index in range(len(candles) - 2, 0, -1):
        candle = candles[index]
        displacement = candles[index + 1]
        if direction == Bias.LONG and candle.close < candle.open and displacement.close > candle.high:
            return candle.low, candle.high
        if direction == Bias.SHORT and candle.close > candle.open and displacement.close < candle.low:
            return candle.low, candle.high
    return None


def validate_setup(
    higher_timeframe: Sequence[Candle],
    entry_timeframe: Sequence[Candle],
    now: datetime | None = None,
) -> Setup:
    """Validate a paper setup in the required SMC order."""

    session = current_session(now)
    range_ = asian_range(higher_timeframe)
    structure = read_structure(higher_timeframe)
    reasons: list[str] = []
    invalidation: list[str] = []
    if session not in {"asian", "london", "new_york"}:
        return Setup(False, Bias.NEUTRAL, None, None, None, None, session, ("Outside the configured Asian/London/New York sessions",), ("Session filter failed",))
    if range_ is None:
        return Setup(False, Bias.NEUTRAL, None, None, None, None, session, ("Asian range is not available",), ("Wait for the Asian range",))
    if structure.bias == Bias.NEUTRAL:
        return Setup(False, Bias.NEUTRAL, None, None, None, None, session, (structure.reason,), ("Wait for BOS/CHoCH confirmation",))

    sell_side, buy_side = liquidity_sweep(entry_timeframe, range_)
    expected_sweep = sell_side if structure.bias == Bias.LONG else buy_side
    if not expected_sweep:
        return Setup(False, structure.bias, None, None, None, None, session, ("Required liquidity sweep is not confirmed",), ("No sweep; do not anticipate the entry",))
    reasons.append("Asian range liquidity swept")

    fvg = find_fvg(entry_timeframe, structure.bias)
    if fvg is None:
        return Setup(False, structure.bias, None, None, None, None, session, tuple(reasons + ["No directional FVG after sweep"]), ("Wait for displacement and FVG",))
    reasons.extend([structure.reason, "BOS/CHoCH displacement confirmed", "Directional FVG identified"])

    risk = abs(fvg.midpoint - (range_.low if structure.bias == Bias.LONG else range_.high))
    if risk <= 0:
        return Setup(False, structure.bias, None, None, None, None, session, tuple(reasons), ("Invalid risk distance",))
    target = fvg.midpoint + 2 * risk if structure.bias == Bias.LONG else fvg.midpoint - 2 * risk
    return Setup(
        True,
        structure.bias,
        fvg.midpoint,
        range_.low if structure.bias == Bias.LONG else range_.high,
        target,
        2.0,
        session,
        tuple(reasons),
        ("Close beyond the swept range", "Invalidate if displacement FVG is filled without reaction"),
    )


def audit_trade(
    setup: Setup,
    *,
    trend_confirmed: bool,
    sweep_confirmed: bool,
    displacement_confirmed: bool,
    session_allowed: bool,
    risk_reward_ok: bool,
    outcome: str,
) -> TradeAudit:
    """Explain a trade outcome with the exact rule that failed or passed."""

    checklist = (
        ("Trend read before entry", trend_confirmed),
        ("Asian range liquidity mapped", sweep_confirmed),
        ("BOS or CHoCH displacement confirmed", displacement_confirmed),
        ("London/New York session active", session_allowed),
        ("Risk/reward at least 1:2", risk_reward_ok),
    )
    failed = [label for label, passed in checklist if not passed]
    if outcome == "won" and not failed:
        return TradeAudit("A", "valid_trade", ("All mandatory SMC gates passed",), checklist)
    if failed:
        return TradeAudit(
            "C",
            "wrong_trade",
            tuple(f"{label} failed" for label in failed),
            checklist,
        )
    return TradeAudit("B", "needs_review", ("Outcome and structure disagree; review the candle sequence",), checklist)